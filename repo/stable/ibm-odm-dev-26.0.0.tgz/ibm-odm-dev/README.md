# ODM for developers Helm chart (ibm-odm-dev)

The [IBM® Operational Decision Manager](https://www.ibm.com/products/operational-decision-manager) (ODM) chart `ibm-odm-dev` is used to deploy an ODM evaluation cluster in IBM  Kubernetes environments.

## Introduction

ODM is a tool for capturing, automating, and governing repeatable business decisions. You identify situations about your business and then automate the actions to take as a result of the insight you gained about your policies and customers. For more information, see [ODM in knowledge center](https://www.ibm.com/docs/en/odm/9.6.0).

**Table of Content**

- [Chart Details](#chart-details)
- [Prerequisites](#prerequisites)
- [Installing the Chart](#installing-the-chart)
- [Chart Requirements](#chart-requirements)
- [Security Requirements](#security-requirements)
- [Configuration](#configuration)
- [Limitations](#limitations)
- [Documentation](#documentation)

---

## Chart Details

The `ibm-odm-dev` Helm chart is a package of preconfigured Kubernetes resources that bootstrap an ODM deployment on a Kubernetes cluster. Configuration parameters are available to customize some aspects of the deployment. However, the chart is designed to get you up and running as quickly as possible, with appropriate default values. If you accept the default values, sample data is added to the database as part of the installation, and you can begin exploring rules in ODM immediately.

The `ibm-odm-dev` chart deploys a single container containing the optional internal database server and the four ODM services:
- Decision Center Business Console
- Decision Server Console
- Decision Server Runtime
- Decision Runner

The `ibm-odm-dev` chart supports the following options for persistence:

- H2 as an **internal database**. This is the **default** option.
Persistent Volume (PV) is required if you choose to use an internal database. PV represents an underlying storage capacity in the infrastructure. PV must be created with accessMode ReadWriteOnce and storage capacity of 2Gi or more, before you install ODM. You create a PV in the Admin console or with a `.yaml` file.
- PostgreSQL as an **external database**. If you specify a server name for the external database, the external database is used, otherwise the internal database is used. Before you select this option, you must have an external PostgreSQL database up and running.

By default, the `internalDatabase.populateSampleData` parameter is set to `true`, which adds sample data to the database. A decision service is created in Decision Center and is also deployed to Rule Execution Server. The sample data can be used to test your newly created release.

> **Note:** The ability to populate the database with sample data is available only when using the internal database and the persistence locale for Decision Center is set to English (United States). Sample data is not available for the external database.

### Architecture

- Three major architectures are now available for ODM for developers Edition worker nodes:
  - AMD64 / x86_64
  - ARM64
  - s390x
  - ppc64le

## Prerequisites

- Kubernetes 1.28+ 
- Helm aligned with the Kubernetes version.
- One PersistentVolume needs to be created prior to installing the chart if `internalDatabase.persistence.enabled=true` and `internalDatabase.persistence.dynamicProvisioning=false`. In that case, it is required that the securityContext.fsGroup 1001 has read and write permissions on the postgres data directory. You can update the permissions by mounting the volume temporarily or accessing the host machine and performing the following commands:

  ```console
  chown -R :1001 /config/dbdata/
  chmod -R ug+rw /config/dbdata/
  chmod o-t /config/dbdata/
  ```

  Refer to [Internal Storage Requirements](#internal-storage-requirements) section for more information.

Ensure you have a good understanding of the underlying concepts and technologies:
- Docker, container
- Kubernetes
- Helm chart, Helm commands
- Kubernetes command line tool

Before you install ODM for developers, you need to gather all the configuration information that you will use for your release. For more details, refer to the [Chart Requirements](#chart-requirements) section.

## Installing the Chart

The following instructions should be executed as namespace administrator. Multiple instances can be deployed in the single cluster and in the single namespace.

1. Add the ibm chart repository:

    ```console
    $ helm repo add ibm-helm https://raw.githubusercontent.com/DecisionsDev/odm-docker-kubernetes/master/repo/stable
    ```

2. Install the chart

    A release must be configured before it is installed.

    Create a `my-values.yaml` file with the following parameters:
    ```yaml
    license: accept
    usersPassword: my-password
    ```

    To install a release with the default configuration and a release name of `my-odm-dev-release`, use the following command:
    ```console
    $ helm install my-odm-dev-release -f my-values.yaml ibm-helm/ibm-odm-dev
    ```

    > **Tip**: List all existing releases with the `helm list` command.

The release is an instance of the `ibm-odm-dev` chart: all the ODM components are now running in a Kubernetes cluster.

### Required parameters

- Review and accept the [product license](LICENSES/LICENSE-LI), by setting the following parameter:
  - `license=view` to print the license agreement (default value)
  - `license=accept` to accept the license

- Define a password to be used by the default users like **odmAdmin** by setting the parameter `usersPassword`.

  > **Note**: To define the users and customize the user access, refer to [Configuring user access](#configuring-user-access)

Refer to the [Configuration](#configuration) section for advanced configuration. You can find the default values of all parameters in the [ODM for developers configuration parameters](https://www.ibm.com/docs/en/odm/9.6.0?topic=reference-odm-developers-configuration-parameters).

### Using helm template

If you plan on using `helm template` command for ODM installation, add the `--validate` flag to validate your manifests against your Kubernetes cluster:

```console
$ helm template my-odm-dev-release \
  --set license=accept \
  --set usersPassword=my-password \
  --validate \
  ibm-helm/ibm-odm-dev > my-values.yaml
$ kubectl apply -f my-values.yaml
```

### Verifying the Chart

#### Port Exposed

The pod exposes only one port externally:

| From |	To | Port	| Protocol | Function |
| ---- | ---- | ---- | ---- | ---- |
| End User | Application | 9060 | HTTP | Communication from the end user to the front end UI of the application |

#### Accessing ODM

1. Navigate to the ODM welcome page

  The welcome page of IBM Operational Decision Manager Developer Edition displays with links to the ODM components and other resources.

  - **Option 1**: Using a route

    If you installed IBM Operational Decision Manager Developer Edition in Openshift, a route to access the welcome page will be automatically created. The page is accessible through this url `http://<route-hostname>`.

    You can find the route hostname by using the following command:
    ```console
    $ oc get routes
    ```

  - **Option 2**: Using a Nodeport service

    On other kubernetes clusters, a Nodeport service is automatically created to access the welcome page. The page is accessible through this url `http://<public-node-ip>:<node-port>`.

    Refer to your cluster documentation to get the `<public-node-ip>` which is the public IP address of your node.
    Then you can get the `<node-port>` value by using this command:
    ```console
    $ kubectl get services
    ```

  - **Option 3**: Using an Ingress controller

    Kubernetes Ingress controllers are the original mechanism for exposing your cluster to external access. Each controller implementation is platform-specific.

    For more information about Ingress, see the [Kubernetes documentation](https://kubernetes.io/docs/concepts/services-networking/ingress/).

    You can create an Ingress object to access the welcome page using the following sample:
    <details>
    <summary>Ingress object sample</summary>

    ```yaml
    apiVersion: networking.k8s.io/v1
    kind: Ingress
    metadata:
      name: my-odm-dev-release-ingress
      annotations:
        kubernetes.io/ingress.class: nginx
        nginx.ingress.kubernetes.io/backend-protocol: HTTP
        nginx.ingress.kubernetes.io/affinity: cookie

    spec:
      tls:
      - hosts:
        - mycompany.com
      rules:
      - host: mycompany.com
        http:
          paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: my-odm-dev-release-ibm-odm-dev
                port:
                  number: 9060
    ```
    </details>

    Then you will be able to access the ODM Welcome page with this URL:  https://mycompany.com, after having edited your hosts file and added the correspondance between `mycompany.com` and the external IP provided by the Ingress controller.

2. Click the **Decision Center Business Console** to open the service in a browser.

3. If you accepted the default persistence, a sample project is available in your ODM release and you can explore and modify the rules and decision tables.

  The *Loan Validation sample* is a decision service that determines whether a borrower is eligible for a loan. The decision service validates transaction data, checks customer eligibility, assigns a score, and computes insurance rates that are based on the assigned score.

  Navigate to the *Library* tab of the **Decision Center** Business Console, select the decision service, then the release and browse *Decision Artifacts* to view the rules and make changes.

4. Now you want to execute the sample decision service to request a loan. Follow the procedure described here [Ruleset execution sample details](https://www.ibm.com/docs/en/odm/9.6.0?topic=execution-ruleset-sample-details).

**Note:** The persistence locale for Decision Center is set to English (United States), which means that the project can be viewed only in English.

### Getting started with business rules

This [tutorial](https://github.com/DecisionsDev/odm-for-container-getting-started/tree/master) is for technical and business users who want an introduction to business rules authoring and management, with IBM Operational Decision Manager (ODM) running in a container environment.

### Uninstalling the chart

To uninstall and delete a release named `my-odm-dev-release`, use the following command:

```console
$ helm delete my-odm-dev-release
```

The command removes all the Kubernetes components associated with the chart, except any Persistent Volume Claims (PVCs). This is the default behavior of Kubernetes, and ensures that valuable data is not deleted. In order to delete the ODM's data, you can delete the PVC using the following command:

```console
$ kubectl delete pvc <release_name>-odm-pvclaim -n <namespace>
```

## Chart Requirements

### Resources Required

You can find below the default resources configuration:

| Service  | CPU Request | CPU Limit | Memory Request (Mi) | Memory Limit (Mi) |
| -------- | ----------- | --------- | ------------------- |------------------ |
| ODM services | 1       | 2         | 1024                | 2048              |

You can customize the CPU and Memory Requests and Limits by using the parameters:
- `resources.limits.cpu`
- `resources.limits.memory`
- `resources.requests.cpu`
- `resources.requests.memory`

### Internal Storage Requirements

Uses cases for H2 as an internal database:

- Persistent storage using Kubernetes dynamic provisioning. Uses the default storageclass defined by the Kubernetes admin or by using a custom storageclass which will override the default.
  - Set global values to:
    - **internalDatabase.persistence.enabled**: `true` (default)
    - **internalDatabase.persistence.useDynamicProvisioning**: `true`
  - Specify a custom *storageClassName* per volume or leave the value empty to use the default *storageClass*.

- Persistent storage using a predefined *PersistentVolumeClaim* or *PersistentVolume* setup prior to the deployment of this chart
  - Set global values to:
    - **internalDatabase.persistence.enabled**: `true` (default)
    - **internalDatabase.persistence.useDynamicProvisioning**: `false` (default)
  - Kubernetes binding process selects a pre-existing volume based on the accessMode and size.

Storage Options Supported:
- IBM Cloud storage options supported:
  - `File Bronze`
  - `File Silver`
  - `File Gold`

On-premise storage options supported for all architectures:
- `Rook-Ceph`

## Security Requirements

### Service Account Requirements

By default, the chart creates and uses a custom service account named `<releasename>-ibm-odm-dev-service-account`.

The service account should be granted the appropriate `SecurityContextConstraints` (SCC) depending on your cluster.
 Refer [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements) documentation for specific guidelines.

You can also configure the chart to use a custom service account. In this case, a cluster administrator can create the custom service account, and the namespace administrator can configure the chart to use this service account by setting the `serviceAccountName` parameter:

```yaml
license: accept
# Set a custom service account
serviceAccountName: ibm-odm-dev-service-account
usersPassword: my-password
```

Run the following command to install:
```console
helm install my-odm-dev-release -f my-values.yaml ibm-helm/ibm-odm-dev
```

### Pod Security

Red Hat OpenShift Container Platform (OCP) provides Pod security using `SecurityContextConstraints` (SCC) resources to enforce policies based on user and group mappings, similar to the Kubernetes Pod Security Policy (PSP) API. Starting with Kubernetes v1.25, the Pod Security Admission (PSA) controller replaces PSP and introduces namespace-based enforcement for Pod security, simplifying management.

From OpenShift 4.11 onwards, the PSA controller which enforces Pod security standards at the namespace level is supported. For more details, refer to [Understanding and Managing Pod Security Admission](https://kubernetes.io/docs/concepts/security/pod-security-admission/).

### Pod Security Context

The following Pod Security Contexts are recommended for ODM pods to comply with Kubernetes and OpenShift security standards (compatible with both the `restricted` SCC in OpenShift <4.11 and `restricted-v2` SCC in OpenShift 4.11+):

```yaml
securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
    - ALL
  runAsNonRoot: true
```

### Security context parameters description

- **`allowPrivilegeEscalation: false`**  
  Prevents processes in the container from gaining additional privileges, even if the process could potentially do so. This is a key security measure to block privilege escalation attempts.

- **`privileged: false`**  
  Disables access to the host’s devices and limits actions requiring root privileges. This ensures that the container's scope of actions is limited, reducing the risk of compromising the node.

- **`readOnlyRootFilesystem: true`**  
  Ensures that the root file system remains immutable, reducing the potential for attacks that involve modifying executable files or system libraries within the container.

- **`capabilities: drop: - ALL`**  
  Drops all Linux capabilities to run the container with the least privileges possible, reducing the attack surface. This follows the principle of least privilege to minimize the risk of privilege escalation.

- **`runAsNonRoot: true`**  
  Enforces that the container runs as a non-root user. If an image attempts to run as the root user (UID 0), the container will fail to start, ensuring that no process in the container has root privileges.

These settings align with the latest Kubernetes security standards and are compatible with Kubernetes-native clusters and OpenShift environments.

For OpenShift-specific changes to Pod Security Standards, see [Important OpenShift changes to Pod Security Standards](https://connect.redhat.com/en/blog/important-openshift-changes-pod-security-standards).

If you are upgrading from older Kubernetes versions to v1.25 and above, refer to [Kubernetes Migrate from PSP](https://kubernetes.io/docs/tasks/configure-pod-container/migrate-from-psp/) for guidance on migrating from PSP to the new PSA controller.

### Red Hat OpenShift SecurityContextConstraints Requirements

This chart requires a SecurityContextConstraints to be granted to the serviceAccount prior to installation.
A cluster administrator can either bind the SecurityContextConstraints to the target namespace or add the scc specifically to the serviceAccount.

The predefined SecurityContextConstraints name: [`restricted`](https://ibm.biz/cpkspec-scc) has been verified for this chart. In Openshift, `restricted` is used by default for authenticated users.

This chart also defines a custom SecurityContextConstraints which can be used to finely control the permissions/capabilities needed to deploy this chart.

You can apply the following yaml file to create the custom SecurityContextConstraints.

  <details>
  <summary>Custom SecurityContextConstraints definition:</summary>

  ```yaml
  apiVersion: security.openshift.io/v1
  kind: SecurityContextConstraints
  metadata:
    annotations:
    name: ibm-odm-scc
  allowHostDirVolumePlugin: false
  allowHostIPC: false
  allowHostNetwork: false
  allowHostPID: false
  allowHostPorts: false
  allowPrivilegedContainer: false
  allowPrivilegeEscalation: false
  allowedCapabilities: []
  allowedFlexVolumes: []
  allowedUnsafeSysctls: []
  defaultAddCapabilities: []
  defaultPrivilegeEscalation: false
  forbiddenSysctls:
    - "*"
  fsGroup:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  readOnlyRootFilesystem: false
  requiredDropCapabilities:
  - ALL
  runAsUser:
    type: MustRunAsNonRoot
  seccompProfiles:
  - docker/default
  seLinuxContext:
    type: RunAsAny
  supplementalGroups:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
  priority: 0
  ```
  </details>

## Configuration

To configure the `ibm-odm-dev` chart, check out the list of available [ODM for developers configuration parameters](https://www.ibm.com/docs/en/odm/9.6.0?topic=reference-odm-developers-configuration-parameters).

### Configuring user access

You can override the default registry configuration and change the default user credentials.

1. Define your user registry configuration according to your needs in a `webSecurity.xml` file.

  You can update the default configuration from the following `websecurity.xml` file:
  ```xml
  <server>
  	<!-- Web application security -->
  	<basicRegistry id="basic" realm="customRealm">
  		<!-- ODM super user -->
  		<user name="odmAdmin" password="my-password"/>
  		<!-- Users for Decision Center -->
  		<user name="rtsAdmin" password="my-password"/>
  		<user name="rtsConfig" password="my-password"/>
  		<user name="rtsUser1" password="my-password"/>
  		<user name="rtsUser2" password="my-password"/>
  		<!-- Users for Decision Server -->
  		<user name="resAdmin" password="my-password"/>
  		<user name="resDeployer" password="my-password"/>
  		<user name="resMonitor" password="my-password"/>
  		<!-- Groups for Decision Center -->
  		<group name="rtsAdministrators">
  			<member name="odmAdmin"/>
  			<member name="rtsAdmin"/>
  		</group>
  		<group name="rtsInstallers">
  			<member name="odmAdmin"/>
  			<member name="rtsAdmin"/>
  		</group>
  		<group name="rtsConfigManagers">
  			<member name="rtsConfig"/>
  		</group>
  		<!-- Groups for Decision Server -->
  		<group name="resAdministrators">
  			<member name="odmAdmin"/>
  			<member name="resAdmin" />
  		</group>
  		<group name="resDeployers">
  			<member name="resDeployer" />
  		</group>
  		<group name="resMonitors">
  			<member name="resMonitor" />
  		</group>
  	</basicRegistry>
  </server>
  ```

2. Create a secret with the `webSecurity.xml` file by running the following command.

  ```console
  kubectl create secret generic my-auth-secret --from-file=webSecurity.xml=myWebSecurity.xml
  ```

  Where `my-auth-secret` is the name you give to your secret, and `myWebSecurity.xml` the name of your user registry configuration file.

3. Pass the name of your secret as the value for the **customization.authSecretRef** parameter when you create the ODM instance.

### Installing Rule Designer

If you want to create your own decision services from scratch, you need to install [Rule Designer](https://www.ibm.com/docs/en/odm/9.6.0?topic=ird-installing-ready-use-rule-designer).

## Limitations

The following ODM on premises features are not supported: [Features not included in this platform.](https://www.ibm.com/docs/en/odm/9.6.0?topic=kubernetes-decision-features-not-included)

# Issues and contributions

For issues relating specifically to the Dockerfiles and scripts, please use the [GitHub issue tracker](https://github.com/ODMDev/odm-ondocker/issues). For more general issue relating to IBM Operational Decision Manager you can [get help](https://community.ibm.com/community/user/automation/communities/community-home?CommunityKey=c0005a22-520b-4181-bfad-feffd8bdc022) through the ODM community or, if you have production licenses for Operational Decision Manager, via the usual support channels. We welcome contributions following [our guidelines](https://github.com/ODMDev/odm-ondocker/blob/master/CONTRIBUTING.md).

## Documentation

See [ODM on Certified Kubernetes in knowledge center](https://www.ibm.com/docs/en/odm/9.6.0?topic=operational-decision-manager-certified-kubernetes-960).
