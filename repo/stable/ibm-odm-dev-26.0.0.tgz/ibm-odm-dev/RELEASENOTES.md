# What's new in Helm chart 26.0.0

The version 26.0.0 of the Helm chart installs version 9.6.0.0 of IBM Operational Decision Manager. For a complete list of new features in this release, go to [What's new](https://www.ibm.com/docs/en/odm/9.6.0?topic=notes-whats-new)

# Prerequisites
1. Kubernetes 1.28 or higher, with Helm 4.0 or higher.
2. For the internal database, create a persistent volume or use dynamic provisioning.

# Documentation
For more information go to [Operational Decision Manager on Certified Kubernetes knowledge center](https://www.ibm.com/docs/en/odm/9.6.0?topic=operational-decision-manager-certified-kubernetes-960)

# Breaking Changes
- IBM Operational Decision Manager for Developers image has migrated from *icr.io/odm-k8s* to *icr.io/cpopen/odm-k8s*.
You can obtain the IBM Operational Decision Manager for Developers image on **icr.io/cpopen/odm-k8s** without authenticating.

  If you are using the ibm-odm-dev charts before 22.1.0, you can migrate to the IBM Registry by setting the `image.repository` parameter to **icr.io/cpopen/odm-k8s** when installing an instance.

  ```
  helm install my-odm-dev-release --set license=accept --set image.repository=icr.io/cpopen/odm-k8s ibm-helm/ibm-odm-dev
  ```

- ODM chart is now available in [ibm-helm](https://github.com/IBM/charts/blob/master/repo/ibm-helm/) repository.

# Upgrading
- When you upgrade the ibm-odm-dev chart from one version to another, if you want to keep your existing data, you must uncheck the "Populate sample data" option.

  Otherwise, the database is recreated with the original sample data and you lose the data generated with the previous version of the chart (reports on the sample project, new decision services...).

# Fixes
[Operational Decision Manager Interim Fixes](http://www.ibm.com/support/docview.wss?uid=swg21640630)

# Version History
| Chart  | Date       | Details                                                                                                                                                                                                      |
|--------|------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 26.0.0 | Jun 2026   | ODM 9.6.0.0 release - Liberty 25.0.0.12  
| 25.1.0 | Dec 2026   | ODM 9.5.0.1 release - Liberty 25.0.0.9  
| 25.0.0 | Jun 2025   | ODM 9.5.0.0 release - Liberty 25.0.0.3 - JDK 21 - New RES Console UI  
| 24.1.0 | Dec 2024   | ODM 9.0.0.1 release - Liberty 24.0.0.9 - Change to Helm - Move to Pod Security Admission                                                                                                                                                                                            | 
| 24.0.0 | June 2024  | ODM 9.0.0 release - Removed image.arch (use manifests everywhere)                                                                                                                                            |
| 23.2.0 | Dec 2023   | ODM 8.12.0.1 release                                                                                                                                                                                         |
| 23.1.0 | June 2023  | ODM 8.12.0.0 release                                                                                                                                                                                         | 
| 22.2.0 | Dec 2022   | ODM 8.11.1.0 release - Improve NetworkPolicies, Update chart api to use v2 and force helm v3, Remove teamserver, Update default repository to `icr.io/cpopen/odm-k8s`                                        |
| 22.1.0 | June 2022  | ODM 8.11.0.1 release                                                                                                                                                                                         |
| 21.3.0 | Dec 2021   | ODM 8.11.0 release - Update Liberty version, Require password for default user access, Add user access configuration, Update default repository to `icr.io/odm-k8s`, Define ephemeral storage default values |
| 21.2.0 | June 2021  | ODM 8.10.5.1 release                                                                                                                                                                                         |
| 21.1.0 | March 2021 | Bug fixing, Default values update, Helm Chart values validation with JSON Schemas                                                                                                                            |
| 20.3.0 | Dec 2020   | ODM 8.10.5 release - Require license acceptance, Add default custom serviceAccount, Support `restricted` scc in Openshift, Digest support, Automate route creation for Openshift                             |
| 20.2.0 | June 2020  | ODM 8.10.4 release - Update Liberty version                                                                                                                                                                  |
| 2.3.0  | Dec 2019   | Bug fixing                                                                                                                                                                                                   |
| 2.2.1  | Sept 2019  | Network policy security isolation                                                                                                                                                                            |
| 2.2.0  | June 2019  | ODM 8.10.2 release - UBI base image                                                                                                                                                                          |
| 2.1.0  | March 2019 | ODM 8.10.1 release - Support for non-root                                                                                                                                                                    |
| 2.0.0  | Dec 2018   | New release ODM 8.10.0.0                                                                                                                                                                                     |
| 1.1.0  | July 2018  | Fix pack 8.9.2.1                                                                                                                                                                                             |
| 1.0.0  | March 2018 | First full release ODM 8.9.2.0                                                                                                                                                                               |
